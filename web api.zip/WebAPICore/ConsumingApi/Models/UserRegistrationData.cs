﻿using System.ComponentModel.DataAnnotations;

namespace ConsumingApi.Models
{
    public class UserRegistrationData
    {
        [Required]
        public string Name { get; set; }
        [Required]
        public string Address { get; set; }
        [Required]
        public long PhoneNo { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public string State { get; set; }
       
        public bool Approved { get; set; }
    }
}
