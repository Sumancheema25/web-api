﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using ConsumingApi.Models;
using Microsoft.AspNetCore.Mvc;

namespace ConsumingApi.Controllers
{
    public class StudentController : Controller
    {
        public IActionResult Index()
        {
            IEnumerable<UserRegistrationData> students = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50031/api/");
                //HTTP GET
                var responseTask = client.GetAsync("values");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<UserRegistrationData>>();
                    readTask.Wait();

                    students = readTask.Result;
                }
                else //web api sent error response 
                {

                    students = Enumerable.Empty<UserRegistrationData>();

                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }
            return View(students);
        }

        public IActionResult Search(string searchText)
        {
            UserRegistrationData student = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50031/api/");
                //HTTP GET
                var responseTask = client.GetAsync("values/" + searchText);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<UserRegistrationData>();
                    readTask.Wait();

                    student = readTask.Result;
                }
                else //web api sent error response 
                {

                    student = new UserRegistrationData();

                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }
            List<UserRegistrationData> students = new List<UserRegistrationData>();
            students.Add(student);
            return PartialView("_Detailed",students);
        }

        public ActionResult Edit(string id)
        {
            UserRegistrationData students = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50031/api/");
                //HTTP GET
                string uri = "values/" + id;
                var responseTask = client.GetAsync(uri);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<UserRegistrationData>();
                    readTask.Wait();

                    students = readTask.Result;
                }
                else //web api sent error response 
                {

                    students = new UserRegistrationData();

                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }
            return View(students);
        }
            public ActionResult Update(UserRegistrationData userRegistration) {
            bool student = false;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50031/api/");

                //HTTP GET
                var responseTask = client.PutAsJsonAsync<UserRegistrationData>("values", userRegistration);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<bool>();
                    readTask.Wait();

                    student = readTask.Result;
                }
            }

            return View("Edit",student);
        }
    }
}