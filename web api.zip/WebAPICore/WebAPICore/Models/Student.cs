﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPICore.Models
{
    public class Student
    {
        string connectionString = @"Data Source=192.168.12.20; Initial Catalog = Training2019; Integrated Security=False;User ID=qancs_imarc;Password=qancs@2019";
        

        public DataTable GetResults(string sqlQuery)
        {

        SqlConnection sqlCon = new SqlConnection(connectionString);
        sqlCon.Open();
        DataTable DtResult = new DataTable();
        SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlQuery, sqlCon);
        sqlDataAdapter.Fill(DtResult);
        return DtResult;

        }

        public DataTable PostValues(string sqlQuery)
        {
            SqlConnection sqlCon = new SqlConnection(connectionString);
            sqlCon.Open();
            SqlCommand sqlCommand = new SqlCommand(sqlQuery, sqlCon);
            sqlCommand.ExecuteNonQuery();
            return null;

        }

    }
}
