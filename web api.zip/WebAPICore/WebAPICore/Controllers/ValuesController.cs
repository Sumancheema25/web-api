﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebAPICore.Models;

namespace WebAPICore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {

        Student student = new Student();
        // GET api/values
        [HttpGet]
        public List<UserRegistrationData> Get()
        {
            DataTable Studenttbl = new Student().GetResults("SELECT * FROM UserRegistration");
            List<UserRegistrationData> listObj = new List<UserRegistrationData>();
            UserRegistrationData obj = null;
            foreach (DataRow DRow in Studenttbl.Rows)
            {
                obj = new UserRegistrationData()
                {
                    Address = DRow["Address"].ToString(),
                    Approved = Convert.ToBoolean(DRow["Approved"]),
                    PhoneNo = Convert.ToInt64(DRow["PhoneNo"]),
                    Email = DRow["Email"].ToString(),
                    Name = DRow["Name"].ToString(),
                    State = DRow["State"].ToString(),
                };
                listObj.Add(obj);
            }
            return listObj;
        
    }

        // GET api/values/5
        [HttpGet("{id}")]
        public UserRegistrationData GetStudent(string id ,int phoneno)
        {
            DataTable Studenttbl = new Student().GetResults("SELECT * FROM UserRegistration WHERE Name = '"+id+"'");
            //DataTable Studenttbl = new Student().GetResults("SELECT id,phoneno * FROM UserRegistration WHERE PhoneNo = '"+phoneno+"'");

            UserRegistrationData obj = null;
            foreach (DataRow DRow in Studenttbl.Rows)
            {
                obj = new UserRegistrationData()
                {
                    Address = DRow["Address"].ToString(),
                    Approved = Convert.ToBoolean(DRow["Approved"]),
                    Email = DRow["Email"].ToString(),
                    Name = DRow["Name"].ToString(),
                    State = DRow["State"].ToString()
                };
                break;
            }
            if (obj == null)
            {
                return new UserRegistrationData();
            }
            else
                return obj;
        }

        // POST api/values
        [HttpPost]
        public DataTable Post(UserRegistrationData data)
        {
            DataTable Studenttbl = new Student().PostValues("INSERT INTO UserRegistration VALUES ('" + data.Name + "' , '" + data.Address + "','" + data.PhoneNo + "','" + data.Email + "','" + data.State + "','" + data.Approved + "')");
            return Studenttbl;
        }

        // PUT api/values/5s
        [HttpPut]
        public bool Put(UserRegistrationData userRegistration)
        {
            
         DataTable Studenttbl = new Student().GetResults("UPDATE UserRegistration SET Approved = '" + userRegistration.Approved+ "' WHERE Name = '"+ userRegistration.Name+ "'; SELECT * FROM UserRegistration WHERE Name = '" + userRegistration.Name + "'");
            UserRegistrationData obj = null;
            foreach (DataRow DRow in Studenttbl.Rows)
            {
                obj = new UserRegistrationData()
                {
                    Address = DRow["Address"].ToString(),
                    Approved = Convert.ToBoolean(DRow["Approved"]),
                    PhoneNo = Convert.ToInt64(DRow["PhoneNo"]),
                    Email = DRow["Email"].ToString(),
                    Name = DRow["Name"].ToString(),
                    State = DRow["State"].ToString(),
                };
                break;
            }
            return true;

        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
