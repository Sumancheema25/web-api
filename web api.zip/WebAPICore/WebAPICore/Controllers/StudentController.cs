﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebAPICore.Models;

namespace WebAPICore.Controllers
{
    public class StudentController : Controller
    {
        public IActionResult Index()
        {
            IEnumerable<UserRegistrationData> students = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50031/api/");
                //HTTP GET
                var responseTask = client.GetAsync("student");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<UserRegistrationData>>();
                    readTask.Wait();

                    students = readTask.Result;
                }
                else //web api sent error response 
                {

                    students = Enumerable.Empty<UserRegistrationData>();

                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }
            return View(students);
        }
    }
}
